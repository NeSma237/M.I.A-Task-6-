"""Greedy caption generation for a single image at inference time (no ground
truth caption available — unlike training's teacher forcing)."""

import torch
from PIL import Image
from src.data.dataset import build_transforms
from src.data.preprocessing import Vocabulary
from src.data.caption_model import CaptionModel


@torch.no_grad()
def generate_caption(model: CaptionModel, image_path: str, vocab: Vocabulary,
                      device, max_len: int = 30, return_attention: bool = False):
    """
    Args:
        model: trained CaptionModel (encoder + decoder)
        image_path: path to an image file
        vocab: the Vocabulary used during training
        max_len: stop generating after this many words even without <end>
        return_attention: if True, also return per-word attention maps for
            visualization (which image region the model looked at for each
            generated word)

    Returns:
        caption (str), and optionally (attention_weights, num_pixels_per_side)
    """
    model.eval()

    transform = build_transforms(train=False)
    image = Image.open(image_path).convert("RGB")
    image_tensor = transform(image).unsqueeze(0).to(device)  # (1, 3, H, W)

    encoder_out = model.encoder(image_tensor)  # (1, num_pixels, encoder_dim)
    num_pixels = encoder_out.size(1)

    h, c = model.decoder.init_hidden_state(encoder_out)
    token = torch.tensor([vocab.sos_idx], device=device)  # (1,)

    output_ids = []
    attn_steps = []

    for _ in range(max_len):
        embedding = model.decoder.embedding(token)  # (1, embed_dim)

        context, alpha = model.decoder.attention(encoder_out, h)
        gate = model.decoder.sigmoid(model.decoder.f_beta(h))
        context = gate * context

        lstm_input = torch.cat([embedding, context], dim=1)
        h, c = model.decoder.lstm_cell(lstm_input, (h, c))

        logits = model.decoder.fc(h)  # (1, vocab_size)
        next_id = int(logits.argmax(dim=1))

        attn_steps.append(alpha.squeeze(0).cpu())  # (num_pixels,)

        if next_id == vocab.eos_idx:
            break
        output_ids.append(next_id)
        token = torch.tensor([next_id], device=device)

    caption = vocab.decode(output_ids)

    if return_attention:
        attn_mat = torch.stack(attn_steps, dim=0) if attn_steps else torch.zeros(1, num_pixels)
        grid_size = int(num_pixels ** 0.5)  # e.g. 49 -> 7
        return caption, attn_mat, grid_size

    return caption